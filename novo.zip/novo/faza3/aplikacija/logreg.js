var korisnici=[];
var registracije=[];
var admin={korisnickoime:"admin",lozinka:"lozinka",vrsta:"Administrator",biljke:[],lokacija:""};

function ucitajIndex(){
    if(localStorage.getItem("korisnici")==null){
        korisnici.push(admin);
        localStorage.setItem("korisnici",JSON.stringify(korisnici));
    }else korisnici=JSON.parse(localStorage.getItem("korisnici"));
   
   document.getElementById("hocureg").addEventListener("click",function(){
    window.location.href="reg.html";
    });
    
    document.getElementById("hoculog").addEventListener("click",function(){
        window.location.href="log.html";
      
    });
}
function citaj(){
    if(localStorage.getItem("korisnici")==null){
        localStorage.setItem("korisnici",JSON.stringify(korisnici));
    }
    else korisnici=JSON.parse(localStorage.getItem("korisnici"));
    if(localStorage.getItem("registracije")==null){
        localStorage.setItem("registracije",JSON.stringify(registracije));
    }
    else registracije=JSON.parse(localStorage.getItem("registracije"));

 


    $(".cv").attr("style","display:none");

      $("#vrstakorisnika").on("change",function(){
        let v=document.getElementById("vrstakorisnika").value;
        
                if(v=="Poljoprivrednik"){
                    $(".lok").attr("style","display:inline");
                    $(".cv").attr("style","display:none");
                }
                else if(v=="Istrazivac"){
                    $(".lok").attr("style","display:none");
                    $(".cv").attr("style","display:inline");
                }
                else{
                    $(".lok").attr("style","display:none");
                    $(".cv").attr("style","display:none");
                }
            
        
       });
       $("#logovanjebtn").on("click",function(){
        let korisnickoime= $("#korisnickoimelog").val();
        let lozinka= $("#lozinkalog").val();

        if(korisnickoime==""){
            alert("Niste uneli korisnicko ime");
        }
        else if(lozinka==""){
            alert("Niste uneli lozinku");
        }
        else{
            for(let i=0;i<korisnici.length;i++){
                if(korisnici[i].korisnickoime==korisnickoime && korisnici[i].lozinka==lozinka){
                    localStorage.setItem("trenutni",JSON.stringify(korisnici[i]));
                    if(korisnici[i].vrsta!="Administrator")window.location.href="mojprofil.html" ;
                   else window.location.href="admin.html";
                    
                }
            }
           
        }
       });
      
       $("#registrovanjebtn").on("click",function(){
        let korisnickoime= $("#korisnickoimereg").val();
        let lozinka= $("#lozinkareg").val();
        let opetlozinka= $("#opetlozinka").val();
        let vrsta= $("#vrstakorisnika").val();
        let lokacija= $("#lokacijatxt").val();
        let cv= $("#cvtxt").val();
        if(!/^.{6,}$/.test(lozinka)){alert("lozinka mora imati barem 6 karaktera");return;}
        if(vrsta!="Poljoprivrednik" && vrsta!="Istrazivac"){
            if(korisnickoime=="" || lozinka=="" || opetlozinka==""){
                alert("Niste uneli sve podatke");
            }
            else{
                if(opetlozinka!=lozinka) alert("Lozinka i ponovljena lozinka se ne poklapaju");
                else {uloguj(korisnickoime,lozinka,vrsta,lokacija,cv); window.location.href="index.html",true;}
            }
        } 
        else{
            if(vrsta=="Poljoprivrednik"){
                if(korisnickoime=="" || lozinka=="" || opetlozinka=="" || lokacija==""){
                    alert("Niste uneli sve podatke");
                }
                else{
                    if(opetlozinka!=lozinka) alert("Lozinka i ponovljena lozinka se ne poklapaju");
                    else{
                       for(let i=0;i<korisnici.length;i++){
                        if(korisnici[i].korisnickoime==korisnickoime) {alert("Postoji vec korisnicko ime");return;}
                       }
                       uloguj(korisnickoime,lozinka,vrsta,lokacija,cv);
                       window.location.href="index.html",true;
                    }
                }
            }
            else{
                if(korisnickoime=="" || lozinka=="" || opetlozinka=="" || cv==""){
                    alert("Niste uneli sve podatke;");
                }
                else{
                    if(opetlozinka!=lozinka) alert("Lozinka i ponovljena lozinka se ne poklapaju");
                else{
                   for(let i=0;i<korisnici.length;i++){
                    if(korisnici[i].korisnickoime==korisnickoime) {alert("Postoji vec korisnicko ime");return;}
                   }

                   uloguj(korisnickoime,lozinka,vrsta,lokacija,cv);
                  
                   window.location.href="index.html";
                }
                }
            }
        }
        
    
    });
   
}






function uloguj(ki,loz,v,lok,cv){
    let k={
        korisnickoime:ki,
        lozinka:loz,
        vrsta:v,
        lokacija:lok,
        cv:cv,
        biljke:[]
    };

    registracije.push(k);
    
   // korisnici.push(k);
    localStorage.setItem("registracije",JSON.stringify(registracije));
   // localStorage.setItem("korisnici",JSON.stringify(korisnici));
    

}