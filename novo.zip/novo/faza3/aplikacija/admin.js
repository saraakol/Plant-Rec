
$(document).ready(function(){
    formiratabelu();
    function formiratabelu(){
        
        if(localStorage.getItem('registracije')!=null){
            var registracije=JSON.parse(localStorage.getItem('registracije'));
           // registracije=[{username:'julija'}];
            
            for (let i=0;i<registracije.length;i++){
                let ime=registracije[i].korisnickoime;
                let red = $("<tr></tr>");
                let celija1 = $("<td></td>").append(
                    $("<span>").innerHTML=ime
                );
                let celija2 = $("<td></td>").append(
                    $("<button>dodaj</button>").attr("class", "btn").addClass("btn-success").attr("id","dodaj"+ime).attr('value','dodaj')
                ).append(
                    $("<button>odbij</button>").attr("class", "btn").addClass("btn-success").attr("id","odbij"+ime).attr('value','odbij')
                );
                red.append(celija1);
                red.append(celija2);
                $('#tabela').append(red); 
            }

        }
    }
    var registracije=JSON.parse(localStorage.getItem('registracije'));
    for(let i=0;i<registracije.length;i++){
        $("#dodaj"+registracije[i].korisnickoime).on('click',function(){
            index=0;
            var korisnici=JSON.parse(localStorage.getItem('korisnici'));
            for (let j=0;j<registracije.length;j++){
                if(registracije[i].korisnickoime==registracije[j].korisnickoime){
                    index=j;
                    korisnici.push(registracije[i]);
                    registracije.splice(index,1);
                }
            }
            localStorage.setItem("korisnici",JSON.stringify(korisnici));
            localStorage.setItem("registracije",JSON.stringify(registracije));
            location.reload();
            
        });
        $("#odbij"+registracije[i].korisnickoime).on('click',function(){
            index=0;
            var korisnici=JSON.parse(localStorage.getItem('korisnici'));
            for (let j=0;j<registracije.length;j++){
                if(registracije[i].korisnickoime==registracije[j].korisnickoime){
                    index=j;
                    registracije.splice(index,1);
                }
            }
            localStorage.setItem("korisnici",JSON.stringify(korisnici));
            localStorage.setItem("registracije",JSON.stringify(registracije));
            location.reload();
            
        });
        
    }
   
    
});