var poruke=[];
var trenkor;
var svi=[];
var poruke2=[];

$(document).ready(function(){
    $("#sveporuke").innerHTML="";

if(localStorage.getItem("poruke1")==null){
    localStorage.setItem("poruke1",JSON.stringify(poruke));
}
else poruke=JSON.parse(localStorage.getItem("poruke1"));

if(localStorage.getItem("poruke2")==null){
    localStorage.setItem("poruke2",JSON.stringify(poruke2));
}
else poruke2=JSON.parse(localStorage.getItem("poruke2"));

trenkor=JSON.parse(localStorage.getItem("trenutni"));

svi=JSON.parse(localStorage.getItem("korisnici"));

var path = window.location.pathname;
var page = path.split("/").pop();
console.log( page );
if(page=="cet.html") {if(poruke!=[]) prikazi(trenkor);}
else if(poruke2!=[]) prikazi2(trenkor);


$("#poruka1btn").on("click",function(){
let porukica=$("#porukica").val();
if(porukica!=""){
    let istrazivaci=[];
    for(let i=0;i<svi.length;i++){
       if(svi[i].vrsta=="Istrazivac") istrazivaci.push(svi[i]);
    }
    let i=Math.floor(Math.random() % (istrazivaci.length + 1));
    if(trenkor.vrsta=="Poljoprivrednik"){
        
        let p1={
            tekst:porukica,
            od:trenkor,
            za:istrazivaci[i]
        }
        poruke.push(p1);
        localStorage.setItem("poruke1",JSON.stringify(poruke));
        prikazi(trenkor);
        
    }
    else if(trenkor.vrsta=="Istrazivac"){
        for(let i=poruke.length-1;i>=0;i--){
            if(poruke[i].za.vrsta=="Istrazivac") {
               
                let p2={
                    tekst:porukica,
                    od:trenkor,
                    za:poruke[i].od
                }
                poruke.push(p2);
                localStorage.setItem("poruke1",JSON.stringify(poruke));
                prikazi(trenkor);
                
            }
         }
    }
    location.reload();
}


});


$("#poruka2btn").on("click",function(){
    let porukica=$("#porukica2").val();
    if(porukica!=""){
        let podrska=[];
        for(let i=0;i<svi.length;i++){
           if(svi[i].vrsta=="Podrska") podrska.push(svi[i]);
        }
        let i=Math.floor(Math.random() % (podrska.length + 1));
        if(trenkor.vrsta!="Podrska"){
            
            let p1={
                tekst:porukica,
                od:trenkor,
                za:podrska[i]
            }
            poruke2.push(p1);
            localStorage.setItem("poruke2",JSON.stringify(poruke2));
            prikazi2(trenkor);
            
        }
        else{
            for(let i=poruke2.length-1;i>=0;i--){
                if(poruke2[i].za.vrsta=="Podrska") {
                   
                    let p2={
                        tekst:porukica,
                        od:trenkor,
                        za:poruke2[i].od
                    }
                    poruke2.push(p2);
                    localStorage.setItem("poruke2",JSON.stringify(poruke2));
                    prikazi2(trenkor);
                    
                }
             }
        }
        location.reload();
    }
    
    
    });

});


function prikazi(korisnik){
    if(korisnik.vrsta=="Istrazivac"){
        $("#sveporuke").innerHTML="";
        let polj;
        for(let i=poruke.length-1;i>=0;i--){
            if(poruke[i].za.korisnickoime==korisnik.korisnickoime){
                polj=poruke[i].od;
                break;
            }
        }
        $("#sveporuke").innerHTML="";
        for(let i=0;i<poruke.length;i++){
            if((poruke[i].od.korisnickoime==korisnik.korisnickoime && polj.korisnickoime==poruke[i].za.korisnickoime)||(poruke[i].za.korisnickoime==korisnik.korisnickoime && polj.korisnickoime==poruke[i].od.korisnickoime)){
                let ppp=$("<label>"+poruke[i].tekst+"</label><br/>");
                if(poruke[i].od.korisnickoime==korisnik.korisnickoime)ppp.css({"color":"black","width":"100%"});
                else ppp.css({"color":"green","width":"100%"});
                $("#sveporuke").append(ppp);
               
            }
        }
    }
   
    else{
        let istr;
        $("#sveporuke").innerHTML="";
        for(let i=poruke.length-1;i>=0;i--){
            if(poruke[i].od.korisnickoime==korisnik.korisnickoime){
                istr=poruke[i].za;
                break;
            }
        }
        
        for(let i=0;i<poruke.length;i++){
            if((poruke[i].od.korisnickoime==korisnik.korisnickoime && istr.korisnickoime==poruke[i].za.korisnickoime)||(poruke[i].za.korisnickoime==korisnik.korisnickoime && istr.korisnickoime==poruke[i].od.korisnickoime)){
                let ppp=$("<label>"+poruke[i].tekst+"</label><br/>");
                if(poruke[i].za.korisnickoime==korisnik.korisnickoime)ppp.css({"color":"black","width":"100%"});
                else ppp.css({"color":"green","width":"100%"});
                $("#sveporuke").append(ppp);
             
            }
        }
    }
    

}



function prikazi2(korisnik){
    if(korisnik.vrsta=="Podrska"){
        $("#sveporuke").innerHTML="";
        let polj;
        for(let i=poruke2.length-1;i>=0;i--){
            if(poruke2[i].za.korisnickoime==korisnik.korisnickoime){
                polj=poruke2[i].od;
                break;
            }
        }
        $("#sveporuke").innerHTML="";
        for(let i=0;i<poruke2.length;i++){
            if((poruke2[i].od.korisnickoime==korisnik.korisnickoime && polj.korisnickoime==poruke2[i].za.korisnickoime)||(poruke2[i].za.korisnickoime==korisnik.korisnickoime && polj.korisnickoime==poruke2[i].od.korisnickoime)){
                let ppp=$("<label>"+poruke2[i].tekst+"</label><br/>");
                if(poruke2[i].od.korisnickoime==korisnik.korisnickoime)ppp.css({"color":"red","width":"100%"});
                else ppp.css({"color":"black","width":"100%"});
                $("#sveporuke").append(ppp);
               
            }
        }
    }
   
    else{
        let istr;
        $("#sveporuke").innerHTML="";
        for(let i=poruke2.length-1;i>=0;i--){
            if(poruke2[i].od.korisnickoime==korisnik.korisnickoime){
                istr=poruke2[i].za;
                break;
            }
        }
        
        for(let i=0;i<poruke2.length;i++){
            if((poruke2[i].od.korisnickoime==korisnik.korisnickoime && istr.korisnickoime==poruke2[i].za.korisnickoime)||(poruke2[i].za.korisnickoime==korisnik.korisnickoime && istr.korisnickoime==poruke2[i].od.korisnickoime)){
                let ppp=$("<label>"+poruke2[i].tekst+"</label><br/>");
                if(poruke2[i].za.korisnickoime==korisnik.korisnickoime)ppp.css({"color":"red","width":"100%"});
                else ppp.css({"color":"black","width":"100%"});
                $("#sveporuke").append(ppp);
             
            }
        }
    }
    

}