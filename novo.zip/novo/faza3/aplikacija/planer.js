$(document).ready(function(){

    $("#tabela").html="";

    let dani=["PON","UTO","SRE","CET","PET","SUB","NED"]
    
    let trenutnikorisnik=JSON.parse(localStorage.getItem("trenutni"));
    let biljke=trenutnikorisnik.biljke;
    let vel=biljke.length;
    
    if(vel==0) {
        let sred=$("<h3>Nemate nijednu biljku</h3>").attr("style","text-align:center");
        $("#sredina").append(sred);
        return;
    }
    
    let biljka=$("<th></th>").attr("id","th1");
    biljka.text("");
    $("#tabela").append(biljka);
    for(let i=2;i<=vel+1;i++){
        let biljka=$("<th></th>").attr("id","th"+i);
        biljka.text(biljke[i-2]);
        $("#tabela").append(biljka);
    }

    for(let i=1;i<=7;i++){
        let tr=$("<tr></tr>").attr("id","tr"+i);
        let td=$("<td><label>"+dani[i-1]+"</label></td>").attr("id","td"+i+"1");
        tr.append(td);
        for(let j=2;j<=vel+1;j++){
            let rand=Math.random()*3;
            let s="";
            while(rand>0){
                s+="<i class='bi bi-droplet'></i>";
                rand--;
            }
            td=$("<td>"+s+"</td>").attr("id","td"+i+""+j);
            tr.append(td);
        }
        $("#tabela").append(tr);
    }

});