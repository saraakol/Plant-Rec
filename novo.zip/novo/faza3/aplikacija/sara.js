var sviKorisnici=[];

function inic(){
    if(localStorage.getItem('korisnici')==null){
        localStorage.setItem('korisnici',JSON.stringify(sviKorisnici));
    }
    else sviKorisnici=JSON.parse(localStorage.getItem('korisnici'));
     var trenutni=JSON.parse(localStorage.getItem('trenutni'));
    document.getElementById('korisnickoime').innerHTML=trenutni.korisnickoime;

    if(trenutni.vrsta=="Istrazivac" || trenutni.vrsta=="Podrska"){
        $("#slikanjebiljkecard").hide();
        $("#planerbiljkecard").hide();
        if(trenutni.vrsta=="Istrazivac" )$("#kontaktiranje").show(); else $("#kontaktiranje").hide();
    }else if(trenutni.vrsta=="Poljoprivrednik"){
        $("#slikanjebiljkecard").show();
        $("#pomoc").show();
        $("#planerbiljkecard").show();
    }
}

function dodajbiljku(){
    if(document.getElementById('pic').value!=""){
         
        if(/1.jpg/.test(document.getElementById('pic').value)){
            sviKorisnici=JSON.parse(localStorage.getItem('korisnici'));
            let tren=JSON.parse(localStorage.getItem('trenutni'));
           // tren={username:'Julija'};
            for(let i=0;i<sviKorisnici.length;i++){
            if(sviKorisnici[i].korisnickoime==tren.korisnickoime){
                sviKorisnici[i].biljke.push('biljka1');
                tren=sviKorisnici[i];
            }
        }
        localStorage.setItem('korisnici',JSON.stringify(sviKorisnici));
        localStorage.setItem('trenutni',JSON.stringify(tren));
            document.location='biljka1.html';
        }
        if(/2.jpg/.test(document.getElementById('pic').value)){
            sviKorisnici=JSON.parse(localStorage.getItem('korisnici'));
            let tren=JSON.parse(localStorage.getItem('trenutni'));
            for(let i=0;i<sviKorisnici.length;i++){
            if(sviKorisnici[i].korisnickoime==tren.korisnickoime){
                sviKorisnici[i].biljke.push('biljka2');
                tren=sviKorisnici[i];
            }
        }
        localStorage.setItem('korisnici',JSON.stringify(sviKorisnici));
        localStorage.setItem('trenutni',JSON.stringify(tren));
            document.location='biljka2.html';
        }
        
    }
    else document.getElementById('greskabiljka').innerHTML='izaberite sliku';
}
 
function izlogujSe(){
    var tren='';
    localStorage.setItem('trenutni',JSON.stringify(tren));
    document.location='index.html';
}